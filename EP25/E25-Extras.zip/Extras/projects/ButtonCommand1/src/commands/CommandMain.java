package commands;

public class CommandMain {
  public static void main(String[] args) {
    Commands.add(new ButtonCommand());
  }
}
