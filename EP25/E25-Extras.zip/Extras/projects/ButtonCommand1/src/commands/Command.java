package commands;

public interface Command {
  public void execute();
}
